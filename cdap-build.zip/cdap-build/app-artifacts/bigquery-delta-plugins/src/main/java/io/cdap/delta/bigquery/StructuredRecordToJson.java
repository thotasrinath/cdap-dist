package io.cdap.delta.bigquery;
/*
 * Copyright © 2019 Cask Data, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

import com.google.common.collect.ImmutableSet;
import com.google.gson.stream.JsonWriter;
import io.cdap.cdap.api.common.Bytes;
import io.cdap.cdap.api.data.format.StructuredRecord;
import io.cdap.cdap.api.data.schema.Schema;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.annotation.Nullable;

/**
 * Util class to convert structured record into json.
 */
public final class StructuredRecordToJson {
  private static final Logger LOG = LoggerFactory.getLogger(StructuredRecordToJson.class);

  private static final DateTimeFormatter DATETIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSSSS");
  private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("HH:mm:ss.SSSSSS");
  // array of arrays and map of arrays are not supported by big query
  private static final Set<Schema.Type> UNSUPPORTED_ARRAY_TYPES = ImmutableSet.of(Schema.Type.ARRAY, Schema.Type.MAP);

  private static final int MAX_LOGICAL_DATE_TIME_FRACTION_PRECISION = 6;
  /* BigQuery format for DateTime: YYYY-[M]M-[D]D[( |T)[H]H:[M]M:[S]S[.F]]
   * [.F]: Up to six fractional digits (microsecond precision)
   */
  private static final Pattern LOGICAL_DATE_PATTERN =
    Pattern.compile("\\d{4}-\\d{1,2}-\\d{1,2}([ T]\\d{1,2}:\\d{1,2}:\\d{1,2}(\\.(\\d+))?)?");
  private static final int TIME_FRACTION_GROUP = 3;

  /**
   * Writes object and writes to json writer.
   *
   * @param writer      json writer to write the object to
   * @param name        name of the field to be written
   * @param object      object to be written
   * @param fieldSchema field schema to be written
   */
  public static void write(JsonWriter writer, String name, Object object, Schema fieldSchema) throws IOException {
    write(writer, name, false, object, fieldSchema);
  }

  /**
   * Writes object and writes to json writer.
   * @param writer json writer to write the object to
   * @param name name of the field to be written
   * @param isArrayItem true if the method is writing array item. This means the name of the array field will not be
   *                    added to the json writer
   * @param object object to be written
   * @param fieldSchema field schema to be written
   */
  private static void write(JsonWriter writer, String name, boolean isArrayItem, Object object,
                            Schema fieldSchema) throws IOException {
    Schema schema = getNonNullableSchema(fieldSchema);
    switch (schema.getType()) {
      case NULL:
      case INT:
      case LONG:
      case FLOAT:
      case DOUBLE:
      case BOOLEAN:
      case STRING:
      case BYTES:
        writeSimpleTypes(writer, name, isArrayItem, object, schema);
        break;
      case ARRAY:
        writeArray(writer, name, object, schema);
        break;
      case RECORD:
        writeRecord(writer, name, object, schema);
        break;
      default:
        throw new IllegalStateException(
          String.format("Field '%s' is of unsupported type '%s'", name, fieldSchema.getType()));
    }
  }

  /**
   * Writes simple types to json writer.
   * @param writer json writer
   * @param name name of the field to be written
   * @param isArrayItem true if the method is writing array item. This means the name of the array field will not be
   *                    added to the json writer
   * @param object object to be written
   * @param schema field schema to be written
   */
  private static void writeSimpleTypes(JsonWriter writer, String name, boolean isArrayItem, Object object,
                                       Schema schema) throws IOException {
    if (!isArrayItem) {
      writer.name(name);
    }

    if (object == null) {
      writer.nullValue();
      return;
    }

    Schema.LogicalType logicalType = schema.getLogicalType();
    if (logicalType != null) {
      switch (logicalType) {
        case DATE:
          writer.value(Objects.requireNonNull(LocalDate.ofEpochDay(((Integer) object).longValue()).toString()));
          break;
        case TIME_MILLIS:
          writer.value(TIME_FORMATTER.format(
            Objects.requireNonNull(LocalTime.ofNanoOfDay(TimeUnit.MILLISECONDS.toNanos(((Integer) object))))));
          break;
        case TIME_MICROS:
          writer.value(TIME_FORMATTER.format(
            Objects.requireNonNull(LocalTime.ofNanoOfDay(TimeUnit.MICROSECONDS.toNanos((Long) object)))));
          break;
        case TIMESTAMP_MILLIS:
          //timestamp for json input should be in this format yyyy-MM-dd HH:mm:ss.SSSSSS
          writer.value(DATETIME_FORMATTER.format(
            Objects.requireNonNull(getZonedDateTime((long) object, TimeUnit.MILLISECONDS))));
          break;
        case TIMESTAMP_MICROS:
          writer.value(DATETIME_FORMATTER.format(
            Objects.requireNonNull(getZonedDateTime((long) object, TimeUnit.MICROSECONDS))));
          break;
        case DECIMAL:
          writer.value(Objects.requireNonNull(getDecimal((byte[]) object, schema)).toPlainString());
          break;
        case DATETIME:
          String strValue = object.toString();
          // Datetime should be already an ISO-8601 string
          // But BigQuery format is stricter than ISO-8601 and does not support Zone and Offset
          // Hence it is more closer to DateTimeFormatter.ISO_LOCAL_DATE_TIME but with microsecond precision
          // Check if the value matches expected format for DateTime and trim time fraction to
          // MAX_TIME_FRACTION_PRECISION if it exceeds it
          strValue = checkAndTrimToMaxSupportedPrecision(strValue);
          writer.value(Objects.requireNonNull(strValue));
          break;
        default:
          throw new IllegalStateException(
            String.format("Field '%s' is of unsupported type '%s'", name, logicalType.getToken()));
      }
      return;
    }

    switch (schema.getType()) {
      case NULL:
        writer.nullValue(); // nothing much to do here.
        break;
      case INT:
      case LONG:
      case FLOAT:
      case DOUBLE:
        writer.value((Number) object);
        break;
      case BOOLEAN:
        writer.value((Boolean) object);
        break;
      case STRING:
        writer.value(object.toString());
        break;
      case BYTES:
        if (object instanceof byte[]) {
          writer.value(Base64.getEncoder().encodeToString((byte[]) object));
        } else if (object instanceof ByteBuffer) {
          writer.value(Base64.getEncoder().encodeToString(Bytes.toBytes((ByteBuffer) object)));
        } else {
          throw new IllegalStateException(String.format("Expected value of Field '%s' to be bytes but got '%s'",
                                                        name, object.getClass().getSimpleName()));
        }
        break;
      default:
        throw new IllegalStateException(String.format("Field '%s' is of unsupported type '%s'",
                                                      name, schema.getType()));
    }
  }

  private static String checkAndTrimToMaxSupportedPrecision(String strValue) {
    Matcher matcher = LOGICAL_DATE_PATTERN.matcher(strValue);
    if (matcher.matches()) {
      String timeFraction = matcher.group(TIME_FRACTION_GROUP);
      //matcher.group returns null for a group if an optional group did not exist in the string
      if (timeFraction != null && timeFraction.length() > MAX_LOGICAL_DATE_TIME_FRACTION_PRECISION) {
        //Trim the time fraction to max supported precision
        String trimmedTimeFraction = timeFraction.substring(0, MAX_LOGICAL_DATE_TIME_FRACTION_PRECISION);
        strValue = new StringBuilder(strValue)
          .replace(matcher.start(TIME_FRACTION_GROUP), matcher.end(TIME_FRACTION_GROUP), trimmedTimeFraction)
          .toString();
      }
    } else {
      //Don't throw exception for now as we might be missing some scenario in the format
      //Let it fail during BigQuery insert in case of wrong format
      LOG.warn("Invalid value {} for DATETIME type, it should match the " +
                 "format YYYY-[M]M-[D]D[( |T)[H]H:[M]M:[S]S[.F]]", strValue);
    }
    return strValue;
  }

  private static void writeArray(JsonWriter writer,
                                 String name,
                                 @Nullable Object value,
                                 Schema fieldSchema) throws IOException {
    if (value == null) {
      throw new RuntimeException(
        String.format("Field '%s' is of value null, which is not a valid value for BigQuery type array.", name));
    }

    Collection collection;
    if (value instanceof Collection) {
      collection = (Collection) value;
    } else if (value instanceof Object[]) {
      collection = Arrays.asList((Object[]) value);
    } else {
      throw new IllegalArgumentException(String.format(
        "A value for the field '%s' is of type '%s' when it is expected to be a Collection or array.",
        name, value.getClass().getSimpleName()));
    }

    Schema componentSchema = getNonNullableSchema(Objects.requireNonNull(fieldSchema.getComponentSchema()));
    if (UNSUPPORTED_ARRAY_TYPES.contains(componentSchema.getType())) {
      throw new IllegalArgumentException(String.format("Field '%s' is an array of '%s', " +
                                                         "which is not a valid BigQuery type.",
                                                       name, componentSchema));
    }

    writer.name(name);
    writer.beginArray();

    for (Object element : collection) {
      // BigQuery does not allow null values in array items
      if (element == null) {
        throw new IllegalArgumentException(String.format("Field '%s' contains null values in its array, " +
                                                           "which is not allowed by BigQuery.", name));
      }
      if (element instanceof StructuredRecord) {
        StructuredRecord record = (StructuredRecord) element;
        processRecord(writer, record, Objects.requireNonNull(record.getSchema().getFields()));
      } else {
        write(writer, name, true, element, componentSchema);
      }
    }
    writer.endArray();
  }

  private static void writeRecord(JsonWriter writer,
                                  String name,
                                  @Nullable Object value,
                                  Schema fieldSchema) throws IOException {
    if (value == null) {
      writer.name(name);
      writer.nullValue();
      return;
    }

    if (!(value instanceof StructuredRecord)) {
      throw new IllegalStateException(
        String.format("Value is of type '%s', expected type is '%s'",
                      value.getClass().getSimpleName(), StructuredRecord.class.getSimpleName()));
    }

    writer.name(name);
    processRecord(writer, (StructuredRecord) value, Objects.requireNonNull(fieldSchema.getFields()));
  }

  private static void processRecord(JsonWriter writer,
                                    StructuredRecord record,
                                    List<Schema.Field> fields) throws IOException {
    writer.beginObject();
    for (Schema.Field field : fields) {
      write(writer, field.getName(), record.get(field.getName()), field.getSchema());
    }
    writer.endObject();
  }

  private static ZonedDateTime getZonedDateTime(long ts, TimeUnit unit) {
    long mod = unit.convert(1, TimeUnit.SECONDS);
    int fraction = (int) (ts % mod);
    long tsInSeconds = unit.toSeconds(ts);
    // create an Instant with time in seconds and fraction which will be stored as nano seconds.
    Instant instant = Instant.ofEpochSecond(tsInSeconds, unit.toNanos(fraction));
    return ZonedDateTime.ofInstant(instant, ZoneId.ofOffset("UTC", ZoneOffset.UTC));
  }

  private static BigDecimal getDecimal(byte[] value, Schema schema) {
    int scale = schema.getScale();
    return new BigDecimal(new BigInteger(value), scale);
  }

  /**
   * Gets non nullable type from provided schema.
   *
   * @param schema schema to be used
   * @return non-nullable {@link Schema}
   */
  private static Schema getNonNullableSchema(Schema schema) {
    return schema.isNullable() ? schema.getNonNullable() : schema;
  }

  private StructuredRecordToJson() {
    //no-op
  }
}
